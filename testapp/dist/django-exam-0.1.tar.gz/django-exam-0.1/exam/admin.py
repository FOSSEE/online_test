from exam.models import Question, Quiz
from django.contrib import admin

admin.site.register(Question)
admin.site.register(Quiz)
