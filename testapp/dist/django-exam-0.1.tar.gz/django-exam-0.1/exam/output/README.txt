This directory contains files generated/saved by users as per their
username.  The test executor will chdir into this user directory for each
user when they run the test.  Do not delete this directory and ensure that
it is writeable by all.